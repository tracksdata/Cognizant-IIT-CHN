public class Item {

    //fill the code
    
    public static Item createItem(String itemDetail) {
        //fill the code
    }
    
    public static Item searchItemByName(String itemName, List<Item> itemList) {
        //fill the code
    }
    
    public static List<Item> findAllItemByPriceRange(List<Item> itemList, Double minRate, Double maxRate) {
        //fill the code
    }
    
}
