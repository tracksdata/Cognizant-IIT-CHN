import java.io.*;
import java.util.*;

public class Main {

    public static void main(String[] args) throws Exception {
        List<Item> itemList = new ArrayList<>();
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
        System.out.println("1. Add items\n2. Search item by name\n3. Get item between price range\n4. Exit\nEnter your choice:");
        Integer choice = Integer.parseInt(br.readLine());
        do {
	        switch (choice) {
	            case 1:
	                System.out.println("Enter the number of items:");
	                Integer noOfItems = Integer.parseInt(br.readLine());
	                for (int i = 0; i < noOfItems; i++) {
	                    Item item = Item.createItem(br.readLine());
	                    itemList.add(item);
	                }
	                break;
	            case 2:
	                //fill the code
	            case 3:
	                //fill the code
	            case 4:
	                //fill the code
	        }

	        System.out.println("1. Add items\n2. Search item by name\n3. Get item between price range\n4. Exit\nEnter your choice:");
	        choice = Integer.parseInt(br.readLine());
        }while(choice!=4);
    }

}
