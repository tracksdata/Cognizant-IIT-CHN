public class Booking {
    
	//fill the code

	public static Map<String,List<Booking>> organizeBookings(List<Booking> bookingList) {
		//fill the code
    }

    public static List<String> findBestServiceEngineer(Map<String,List<Booking>> bookingMap) {
        //fill the code
    }
    
}
