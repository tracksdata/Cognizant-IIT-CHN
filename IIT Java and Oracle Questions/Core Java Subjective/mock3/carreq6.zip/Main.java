import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public class Main {
    
    public static void main(String[] args) throws Exception {
        SimpleDateFormat sdf = new SimpleDateFormat("dd-MM-yyyy");
        
        BufferedReader br =  new BufferedReader(new InputStreamReader(System.in));
        String ch="yes";
        do {
            System.out.println("Enter a booking detail:");
            //fill the code
            System.out.println("Do you want to add another booking detail:");
            //fill the code
        }while (ch.equalsIgnoreCase("yes"));
        
        //fill the code
        System.out.format("%-15s %s\n","Name","No of Booking");
        //fill the code
    }
    
}
