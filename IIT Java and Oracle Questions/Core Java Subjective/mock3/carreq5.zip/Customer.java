public class Customer {

	//fill the code
    
}
