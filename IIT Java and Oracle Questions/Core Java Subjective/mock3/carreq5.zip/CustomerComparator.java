
public class CustomerComparator {

    //fill the code
    
}
