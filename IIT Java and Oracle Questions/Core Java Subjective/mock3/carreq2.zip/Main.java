import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;

public class Main {

    
    public static void main(String[] args) throws IOException {
         
        ArrayList<Car> carList = new ArrayList<Car>();        
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
        while(true)
        {
          String menu = "Menu: \n1) Add a Car\n" +"2) Find a Car\n" +"3) Find CarList\n" +"4) Exit";
          System.out.println(menu);
           //fill the code
           if(option == 1) {
    	        //fill the code
		    }
		    if(option == 2) {
		        System.out.println("Licence Number");
		        //fill the code
		    }
		    if(option == 3) {
		        System.out.println("Model");
		        //fill the code
		    }
		    if(option == 4) {
		        //fill the code
		    }
           
        }
    }
}
