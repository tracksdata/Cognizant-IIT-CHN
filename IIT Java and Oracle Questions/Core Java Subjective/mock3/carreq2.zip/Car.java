import java.io.BufferedReader;
public class Car {
    //fill the code
    
    //Dont change the specification of this method
    public static Car addCar(BufferedReader br) {
       
       String licenceNumber, model;Double currentMileage;Integer engineSize;String otherCarDetails;
       Car c = null;
       try {
           System.out.println("Licence Number: ");
           licenceNumber = br.readLine();
           System.out.println("Model: ");
           model = br.readLine();
           System.out.println("Current Mileage: ");
           currentMileage = Double.parseDouble(br.readLine());
           System.out.println("Engine Size: ");
           engineSize = Integer.parseInt(br.readLine());
           c = new Car(licenceNumber,model,currentMileage,engineSize);
           
       }
       catch(Exception e) {
           System.out.println("Could not create Car");
       }
       return c;
       
   }
    
    public static Car findCar(String licNo, ArrayList<Car> carList) {
       //fill the code
     }
    
     public static ArrayList<Car> findCarList(String model, ArrayList<Car> carList) {
       //fill the code
     }
}
