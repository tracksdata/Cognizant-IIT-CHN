import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;



public class Customer{

    private Integer id;
    private String name;
    private String email;
    private String state;
    private String country;

    public Customer(){}

    public Customer(Integer id, String name, String email, String state, String country) {
        //fill the arguements
    }
    
    //Generate getters and setters.

    //fill code here.
    
    public static List<Customer> customerList = new ArrayList<>();
  
    public static Map<String, Integer> convertCsvToMap(List<String> csvDetails)
    {
        //fill code here.
    }
 
    public static List<Customer> getCustomerListFromMap(Map<String, Integer> customerMap)
    {
        //fill code here.
    }
    
}
