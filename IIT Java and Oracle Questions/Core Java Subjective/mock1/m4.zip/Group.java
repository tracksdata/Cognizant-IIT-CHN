import java.util.List;
public class Group {
	//fill the code
	public Boolean removeContactFromGroup(String name) {
		//fill the code
	}
	public void displayContacts() {
		//fill the code
	}
}
