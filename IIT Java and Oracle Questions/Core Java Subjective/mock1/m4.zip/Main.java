import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.text.ParseException;
import java.util.ArrayList;
public class Main {
	public static void main(String[] args) throws IOException, ParseException {
		BufferedReader buff = new BufferedReader(new InputStreamReader(System.in));
		System.out.println("Enter the group name:");
		//fill the code
		System.out.println("1.Add Contact\n2.Delete Contact\n3.Display contacts\n4.Exit\nEnter your choice:");
		Integer choice=Integer.parseInt(buff.readLine());
		//fill the code
	}
}
