import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
public class Contact {
	//fill the code
	public static Contact createContact(String detail) throws ParseException {
		//fill the code
	}
	public String toString() {
		//fill the code
	}
}
