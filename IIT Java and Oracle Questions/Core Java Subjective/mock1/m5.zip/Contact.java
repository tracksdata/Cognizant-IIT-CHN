public class Contact {
	//fill the code
	public static Contact createContact(String detail) throws Exception{
		//fill the code
	}
}
