public class DomainComparator {
	//fill the code
}
