import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
public class Main {
    public static void main(String args[]) throws Exception{
		BufferedReader buff=new BufferedReader(new InputStreamReader(System.in));
		System.out.println("1.Email Validation\n2.Service Provider Identification\nEnter your choice:");
		Integer choice=Integer.parseInt(buff.readLine());
		if(choice==1) {
			System.out.println("Enter the email to be validated:");
			//fill your code
		}
		else if(choice==2) {
			System.out.println("Enter the mobile number to identify the service provider:");
			//fill your code
		}
	}
	public static Boolean validateEmailId(String email) {
			//fill your code	
	}

	public static String identifyServiceProvider(String mobile) {
			//fill your code	
	}
}

