import java.util.ArrayList;
import java.util.Date;
import java.util.List;
public class ContactBO {
	public List<Contact> findContact(List<Contact> contactList,List<String> name){
		//fill the code
	}
	public List<Contact> findContact(List<Contact> contactList,Date dateCreated){
		//fill the code
	}
	public List<Contact> findContact(List<Contact> contactList,String emailDomain){
		//fill the code
	}
}
