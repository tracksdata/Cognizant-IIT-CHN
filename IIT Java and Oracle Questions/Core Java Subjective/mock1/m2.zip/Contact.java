public class Contact {
	//fill the code
}
