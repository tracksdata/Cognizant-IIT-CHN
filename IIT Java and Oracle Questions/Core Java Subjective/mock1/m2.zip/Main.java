import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
public class Main {
    public static void main(String[] args)throws Exception {
		BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
		List<Contact> list=new ArrayList<Contact>();
		SimpleDateFormat sdf=new SimpleDateFormat("dd-MM-yyyy");
		ContactBO cb = new ContactBO();
		System.out.println("Enter the number of contact details:");
		int n = Integer.parseInt(br.readLine());
		//fill you code
		System.out.println("Enter a search type:\n1.Name\n2.Date created\n3.Email domain");
		int choice=Integer.parseInt(br.readLine());
		if(choice==1){
			System.out.println("Enter the names:");
			String names=br.readLine();
			//fill you code
		}
		else if(choice==2){
			System.out.println("Enter the date to search contacts that were created on that date");
			//fill you code	
	}
		else if(choice==3){
			System.out.println("Enter the Email domain to search contacts that have same email domain");
			String domain=br.readLine();
			//fill you code	
			}
		else{
			System.out.println("Invalid choice");
		}
	}
}

