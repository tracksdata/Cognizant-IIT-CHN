public class CreditCardPayment {
	
    //fill the code
    
}
