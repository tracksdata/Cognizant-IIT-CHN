public class PaymentMode {
    
    //fill the code
    
}
