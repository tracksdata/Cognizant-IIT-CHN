public class Car {
	
    //fill the code
    
}
