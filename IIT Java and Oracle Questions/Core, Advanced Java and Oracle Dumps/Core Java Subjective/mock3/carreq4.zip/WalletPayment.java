public class WalletPayment {

    //fill the code
    
}
