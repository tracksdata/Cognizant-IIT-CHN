import java.util.Map;
import java.util.Map.Entry;

public class PaymentUtil {
    
    public Double makePayment(Map<String,Float> bankTax,String bankName,Double amount)
    {
        //fill code here.
    }
    
    public Double makePayment(Double amount)
    {
        Float serviceTax = 5.2f;
        Float vat = 2.3f;
        //fill code here.
    }
    
    public Double makePayment(Double amount, Float discountPercent)
    {
        //fill code here.
    }
    
}
