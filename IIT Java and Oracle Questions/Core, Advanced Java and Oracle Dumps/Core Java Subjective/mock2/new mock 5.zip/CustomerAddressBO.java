import java.text.SimpleDateFormat;
import java.util.*;
public class CustomerAddressBO {
    SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss");
    public List<Customer> populateCustomers(List<String> csvList) throws Exception
    {
        //fill code here.
    }
    public List<Customer> findCustomerNameFromList(List<Customer>customers,String subString) throws Exception
    {
        //fill code here.
    }
    
    
}
