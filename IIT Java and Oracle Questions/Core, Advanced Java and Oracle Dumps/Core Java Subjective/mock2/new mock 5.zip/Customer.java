import java.util.Date;

public class Customer {

    private Long id;
    private String name;
    private Character gender;
    private String email;
    private String contactNumber;
    private Date createdOn;

    public Customer(Long id, String name, Character gender, String email, String contactNumber, Date createdOn) 	{
        //fill the arguements.
    }

	//Generate getters and setters.
    
}
