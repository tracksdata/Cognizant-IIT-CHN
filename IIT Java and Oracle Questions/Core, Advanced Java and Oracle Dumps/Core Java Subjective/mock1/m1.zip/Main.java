import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.text.SimpleDateFormat;
public class Main {
	public static void main(String[] args)throws Exception {
		BufferedReader buff=new BufferedReader(new InputStreamReader(System.in));
		Contact[] contacts = new Contact[2];
		for(int i=0;i<2;i++) {
			System.out.println("Enter contact "+(i+1)+" detail:");
			String split = buff.readLine();
		//fill the code
	}
		//fill the code
	}
}
