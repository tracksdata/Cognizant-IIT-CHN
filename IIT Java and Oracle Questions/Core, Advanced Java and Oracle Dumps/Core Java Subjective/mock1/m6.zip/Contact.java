import java.util.Date;
import java.util.TreeMap;
import java.util.List;
import java.util.Map;
public class Contact {
	//fill the code
	public static Map<String,Integer> getContactCountForDomain(List<Contact> list) {
		//fill the code
	}
}
