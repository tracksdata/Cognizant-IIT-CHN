import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
public class Main {
	public static void main(String[] args) throws Exception{
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		List<Contact> list = new ArrayList<Contact>();
		SimpleDateFormat sdf = new SimpleDateFormat("dd-MM-yyyy");
		System.out.println("Enter the number of contacts:");
		int n = Integer.parseInt(br.readLine());
		//fill the code
		System.out.format("%-15s %s\n","Domain Name","Count");
		//fill the code
	}
}
