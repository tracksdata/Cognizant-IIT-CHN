
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.GregorianCalendar;
import java.util.regex.Matcher;
import java.util.regex.Pattern;


public class Main {
    
    public static void main(String[] args) throws IOException {
        String menu = "Menu: \n 1) Valid Car registration Number \n 2) Convert Car registration Number \n "
                + "3) Valid Driving License";
        
        //TN-07-AS-1273
        System.out.println(menu);
        System.out.println("Enter choice");
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
        int x = Integer.parseInt(br.readLine());
        String regnum = "",input="";
        switch(x) {
            case 1: {
                System.out.println("car registration number");
                regnum = br.readLine();
                validateRegNum(regnum);
            }
            case 2: {
                System.out.println("car registration number");
                regnum = br.readLine();
                convertRegNum(regnum);
            }
            case 3: {
                System.out.println("driving license issue date");
                input = br.readLine();
                validateDrivingLicense(input);
            }
            
        }
        
        
        
    }
    
    public static void validateRegNum(String reg) {
    }

    public static void convertRegNum(String reg) {
    }
    
    public static void validateDrivingLicense(String inp) {
    }
    
}
