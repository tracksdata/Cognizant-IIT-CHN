import java.util.List;

public class Item {
    
    //fill the code
    
    public static Double calculateTotalBill(List<Item> itemList) {
        //fill the code
    }
    
    public static Double calculateTotalBill(List<Item> itemList, Integer deliveryType) {
        //fill the code
    }
    
}
