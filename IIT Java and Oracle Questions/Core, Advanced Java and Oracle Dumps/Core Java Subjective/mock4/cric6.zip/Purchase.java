import java.util.Date;
import java.util.Map;
public class Purchase {
	//fill the code
	public static void obtainPurchaseWithItem(Map<String, Integer> map,String purchaseDetail) {
		//fill the code
	}
}
