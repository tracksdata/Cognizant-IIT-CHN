import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.regex.Pattern;
public class Main {

    public static void main(String[] args) throws Exception {
        SimpleDateFormat sdf = new SimpleDateFormat("dd-MM-yyyy");
        String couponCode;
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
        System.out.println("Enter the coupon code:");
        couponCode = br.readLine();
        System.out.println("1.Validate coupon code\n2.Check validity of coupon code\nEnter the choice:");
        //fill the code
    }
    
    public static boolean validateCouponCode(String couponCode) {
        //fill the code
    }
    
    public static boolean checkValidityOfCouponCode(String couponCode, Date boughtDate) throws Exception {
        //fill the code
    }
    
}
