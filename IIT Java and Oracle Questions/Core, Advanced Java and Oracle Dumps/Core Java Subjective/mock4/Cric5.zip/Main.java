import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
public class Main {
	public static void main(String[] args) throws IOException, NumberFormatException, ParseException {
		BufferedReader buff = new BufferedReader(new InputStreamReader(System.in));
		String currentLine;
		List<Purchase> purchases = new ArrayList<Purchase>();
		System.out.println("Enter the number of purchase:");
		Integer purchaseCount = Integer.parseInt(buff.readLine());
		System.out.println("Enter the purchase details:");
		//fill the code
		System.out.println("Whole sale purchases:");
		System.out.format("%-10s %-15s %s\n","ID","User","Amount");
		//fill the code
	}
}
