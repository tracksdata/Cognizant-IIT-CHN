public class Purchase {
	//fill the code
}
