public class Car {
	
	
	private String licenceNumber;

	public String getLicenseNumber() {
		return licenceNumber;
	}

	

	public void setLicenceNumber(String licenceNumber) {
		this.licenceNumber = licenceNumber;
		
	}
	
    
}
