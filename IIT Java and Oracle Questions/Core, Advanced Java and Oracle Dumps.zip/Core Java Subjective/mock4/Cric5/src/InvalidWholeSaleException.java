public class InvalidWholeSaleException extends Exception
{
	public InvalidWholeSaleException(String s)
	{
		super(s);
	}
}
