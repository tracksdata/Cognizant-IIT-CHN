package com.jessitron.fp4j6;

public interface FunctionOverTime {
    public Double valueAt(final Integer time);
}
